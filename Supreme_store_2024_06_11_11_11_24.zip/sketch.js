//variáveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;
let raio = diametro /2

//velocidade da bolinha
let velocidadeXBolinha = 8;
let velocidadeYBolinha = 8;

//variaveis raquete
let xRaquete = 6;
let yRaquete = 200;
let comprimentoRaquete = 10;
let larguraRaquete = 90;
let acabamentoRaquete = 5;
let raquete;


//variaveis Oponetne
let xRaqueteOponente = 583;
let yRaqueteOponente = 200;
let velocidadeYOponente;

let colidiu = false;

//placar do game
let meusPontos = 0;
let pontosOponente = 0;

// sons
let ponto;
let trilha;
let raquetada;

// variaveis meu sabre
var lsabre = 100;
var hsabre = 130;
var xsabre = -40;
var ysabre = 20;
var sabre;

function preload(){
  sabre = loadImage("sabre.png");
}
function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  image(sabre, xsabre, ysabre, lsabre, hsabre);
  movimentasabre();
}

function preload(){
  trilha = loadSound("trilha.mp3");
  pontos = loadSound("pontos.mp3");
  raquetada = loadSound("raquetada.mp3");
}
function setup() {
    createCanvas(600, 400);
    trilha.play();
}

function draw() {
    background(0, 100);
    mostraBolinha();
    movimentaBolinha();
    colisaoBorda();
    mostraRaquete(xRaquete, yRaquete);  
    movimentaRaquete();
    // colisaoRaquete();
    verificaColisaoRaquete(xRaquete, yRaquete);
    mostraRaquete(xRaqueteOponente, yRaqueteOponente);
    movimentacaoOponete();
    verificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
    incluiPlacar();
    marcaPontos();
}
  
function mostraBolinha(){
  circle(xBolinha, yBolinha, diametro);
    }
function movimentaBolinha(){
  xBolinha += velocidadeXBolinha;
    yBolinha += velocidadeYBolinha;}
function colisaoBorda(){
    if (xBolinha +raio> width || xBolinha -raio< 0) {
        velocidadeXBolinha *= -1;
    }
    if (yBolinha +raio> height || yBolinha -raio < 0) 
        velocidadeYBolinha *= -1;}

function mostraRaquete(x,y){
  rect (x, y, comprimentoRaquete,  larguraRaquete, acabamentoRaquete);
  }
  
function movimentaRaquete(){
 if (keyIsDown(UP_ARROW)){
  yRaquete -= 12;
 }
 if (keyIsDown(DOWN_ARROW)){
   yRaquete += 12;
 }}
function verificaColisaoRaquete(){
  if(xBolinha - raio < xRaquete + comprimentoRaquete  && yBolinha - raio < yRaquete + larguraRaquete && 
yBolinha + raio > yRaquete){
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}
function verificaColisaoRaquete(x,y){
  colidiu = collideRectCircle(x, y, comprimentoRaquete, larguraRaquete, xBolinha, yBolinha, raio);
  if (colidiu){
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}
  function movimentacaoOponete (){
  velocidadeYOponente = yBolinha - yRaqueteOponente - comprimentoRaquete /2 - 30;
  yRaqueteOponente += velocidadeYOponente
  } 
 function incluiPlacar(){
   stroke(209, 170, 92)
   textAlign(CENTER);
   textSize(20);
   fill(color(0,156,256));
   rect(179, 10, 43, 19);
   fill(256);
   text(meusPontos, 200, 26);
   fill(color(256,0,50));
   rect(380, 10, 43, 19);
   fill(256);
   text(pontosOponente, 400, 26);
   
 }
 function marcaPontos(){
   if(xBolinha > 595){
     meusPontos += 1;
     pontos.play();
   }
   if(xBolinha < 5){
     pontosOponente += 1;
     pontos.play();
   }
 }